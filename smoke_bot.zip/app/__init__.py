"""App package initialization."""
